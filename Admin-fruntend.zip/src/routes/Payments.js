import "../assets/css/dashboard.css"
import "../assets/fonts/Ubuntu/Ubuntu-Bold.eot"
import "../assets/fonts/Ubuntu/Ubuntu-Bold.ttf"
import "../assets/fonts/Ubuntu/Ubuntu-Bold.woff"
import "../assets/fonts/Ubuntu/Ubuntu-Bold.woff2"
import "../assets/fonts/Ubuntu/Ubuntu-Light.ttf"
import "../assets/fonts/Ubuntu/Ubuntu-Light.woff"
import "../assets/fonts/Ubuntu/Ubuntu-Light.woff2"
import "../assets/fonts/Ubuntu/Ubuntu-Light.eot"
import "../assets/fonts/Ubuntu/Ubuntu-Medium.ttf"
import "../assets/fonts/Ubuntu/Ubuntu-Medium.eot"
import "../assets/fonts/Ubuntu/Ubuntu-Medium.woff"
import "../assets/fonts/Ubuntu/Ubuntu-Medium.woff2"
import "../assets/fonts/Ubuntu/Ubuntu-Regular.ttf"
import "../assets/fonts/Ubuntu/Ubuntu-Regular.eot"
import "../assets/fonts/Ubuntu/Ubuntu-Regular.woff"
import "../assets/fonts/Ubuntu/Ubuntu-Regular.woff2"
import "../css/pay.css"
import axios from "axios"
import { useState } from "react"
import '../css/login.css'











function Payments(props){

      const [credentials,setcredentials]=useState({id:""});
      const [logininfo, setLogininfo] = useState({});


     const OnTextChange=(args)=>{
      var copyOfcredentials = {...credentials};
      copyOfcredentials[args.target.name]=args.target.value;
      setcredentials(copyOfcredentials);
   }


  const getpay=()=>{
    if(credentials.id === "")
    {
      alert("Enter valid id");
    }
    else{
    axios.get("http://localhost:1111/Payment/"+credentials.id)
    .then((res)=>{
      console.log(res.data);
       setLogininfo(res.data);
    })
  }
  }



    return(<>   
    
      <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <title>Admin</title>
    
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css"/>
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css"/>
    
    <link rel="stylesheet" href="assets/css/style.css"/>
    <link rel="shortcut icon" href="assets/images/favicon.ico" />
 
  <div>
    <div className="container-scroller">
      <div className="row p-0 m-0 proBanner" id="proBanner">
        <div className="col-md-12 p-0 m-0">
          <div className="card-body card-body-padding d-flex align-items-center justify-content-between">
            <div className="ps-lg-1">
              <div className="d-flex align-items-center justify-content-between">
               
                <p style={{color:"antiquewhite" ,marginTop:"10px" }}>Welcome Admin</p>
              </div>
            </div>
          
          </div>
        </div>
      </div>
      </div>
     
      <nav className="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div className="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a className="navbar-brand brand-logo" href="index.html"><img src="assets/images/logo.svg" alt="logo" /></a>
          <a className="navbar-brand brand-logo-mini" href="index.html"><img src="assets/images/logo-mini.svg" alt="logo" /></a>
        </div>
        <div className="navbar-menu-wrapper d-flex align-items-stretch">
          <button className="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span className="mdi mdi-menu"></span>
          </button>
          <div className="search-field d-none d-md-block">
            <form className="d-flex align-items-center h-100" action="#">
              <div className="input-group">
                <div className="input-group-prepend bg-transparent">
                  <i className="input-group-text border-0 mdi mdi-magnify"></i>
                </div>
                <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects"/>
              </div>
            </form>
          </div>
          <ul className="navbar-nav navbar-nav-right">
            <li className="nav-item nav-profile dropdown">
              <a className="nav-link dropdown-toggle" id="profileDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                <div className="nav-profile-img">
                  <img src="assets/images/faces/face1.jpg" alt="image"/>
                  <span className="availability-status online"></span>
                </div>
               
              </a>
              
            </li>
           
            
            
            
            
          </ul>
          
        </div>
      </nav>
   
      <div className="container-fluid page-body-wrapper">
      
        <nav className="sidebar sidebar-offcanvas" id="sidebar">
          <ul className="nav">
            <li className="nav-item nav-profile">
              <a href="./Dashboard" className="nav-link">
                <div className="nav-profile-image">
                  <h1>Dashboard</h1>
                  
                  
                </div>
                <div className="nav-profile-text d-flex flex-column">
                 
                </div>
                <i className="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="index.html">
                <span className="menu-title">Manage Services</span>
                <img src="/assets/images/dashboard/home.png"></img>
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" data-bs-toggle="collapse" href="./Services" aria-expanded="false" aria-controls="ui-basic">
                <span className="menu-title">Manage Service Centers</span>
                <i className="menu-arrow"></i>
                <i className="mdi mdi-crosshairs-gps menu-icon"></i>
              </a>
              <div class="collapse" id="ui-basic">
                <ul className="nav flex-column sub-menu">
                  <li className="nav-item"> <a class="nav-link" href="pages/ui-features/buttons.html">Buttons</a></li>
                  <li className="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Typography</a></li>
                </ul>
              </div>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="./Users">
                <span className="menu-title">Manage Users</span>
                <i className="mdi mdi-contacts menu-icon"></i>
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="./Payments">
                <span className="menu-title">Manage Payments</span>
                <i className="mdi mdi-format-list-bulleted menu-icon"></i>
              </a>
            </li>
           

            
           
           
          </ul>
        </nav> 
        <div className="main-panel">
          <div className="content-wrapper">
            <div className="page-header">
              <h3 className="page-title">
                <br/>
                <span className="page-title-icon bg-gradient-primary text-white me-2">
                  <img src="assets/images/dashboard/img_1.jpg" className="mdi mdi-home" ></img>
                   </span> Payments

                   <br/>




                   <div class="right">
      <input type="number"
             placeholder="Enter user Id "
             value={credentials.id}
             name="id"
             onChange={OnTextChange}
             />
             <br/>
             <br/>
             <button className="boxx-form-right-button" type="submit" onClick={getpay}><h1>Check Payments</h1></button>
  
    </div>
               </h3>
              </div>


		<meta charset="utf-8"/>
		<title>Payments</title>
		<link rel="stylesheet" href="dashboard.css"/>
		<link rel="license" href="https://www.opensource.org/licenses/mit-license/"/>
		
	
	<div>
		<header>
			<h1>Invoice</h1>
			<address contenteditable>
				<p>{logininfo.fname}</p>
				<p>101 E. Chapman Ave Orange, CA 92866</p>
				<p>(800) 555-1234</p>
			</address>
			  <span>
                <img  src="http://www.jonathantneal.com/examples/invoice/logo.png"/><input type="file" accept="image/"/>
               </span>
		</header>
		<article>
			<h1>Recipient</h1>
			<address contenteditable>
				<p>Some Company<br/>c/o Some Guy</p>
			</address>
			<table class="meta">
				<tr>
					<th><span contenteditable>Payment Id</span></th>
					<td><span contenteditable><center>{logininfo.paymentId}</center></span></td>
				</tr>
				<tr>
					<th><span contenteditable>Date</span></th>
					<td><span contenteditable><center>{logininfo.paymentDate}</center></span></td>
				</tr>
				<tr>
					<th><span contenteditable>Address</span></th>
					<td><span>{logininfo.status}</span></td>
				</tr>
			</table>
			<table class="inventory">
				<thead>
					<tr>
						<th><span contenteditable>Item</span></th>
						<th><span contenteditable>Description</span></th>
						<th><span contenteditable>Rate</span></th>
						<th><span contenteditable>Quantity</span></th>
						<th><span contenteditable>Price</span></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><a class="cut">-</a><span contenteditable>Front End Consultation</span></td>
						<td><span contenteditable>Experience Review</span></td>
						<td><span data-prefix>$</span><span contenteditable>150.00</span></td>
						<td><span contenteditable>4</span></td>
						<td><span data-prefix>$</span><span>600.00</span></td>
					</tr>
				</tbody>
			</table>
			
			<table class="balance">
				<tr>
					<th><span contenteditable>Total</span></th>
					<td><span>{logininfo.total}</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Amount Paid</span></th>
					<td><span data-prefix>$</span><span contenteditable>0.00</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Balance Due</span></th>
					<td><span data-prefix>$</span><span>600.00</span></td>
				</tr>
			</table>
		</article>
		<aside>
			<h1><span contenteditable>Additional Notes</span></h1>
			<div contenteditable>
				<p>A finance charge of 1.5% will be made on unpaid balances after 30 days.</p>
			</div>
		</aside>
	</div>

            </div>
        </div>
    </div>
</div>  
    
    
    </>);
}

export default Payments;
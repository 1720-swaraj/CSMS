import "../css/users.css"
import { useState } from "react";
import axios from "axios";
import { useEffect } from "react";


function Users()
{
     const [credentials,setcredentials]=useState({id:""});
     const [logininfo, setLogininfo] = useState([]);

     useEffect(() => {
        getcus();
      },[]);

   const OnTextChange=(args)=>{
    var copyOfcredentials = {...credentials};
    copyOfcredentials[args.target.name]=args.target.value;
    setcredentials(copyOfcredentials);
    }


              const getcus=()=>{
                      axios.get("http://localhost:1111/Users/get")
                       .then((res)=>{
                        setLogininfo(res.data);
                 })
                }

//   const addcus   =()=>{
//     axios.post("http://localhost:6969/Users/login",credentials)
//         .then((res)=>{
//            setLogininfo(res.data);
//         })
 
const delpay=()=>{
    axios.delete("http://localhost:1111/Users/"+credentials.id)
    .then((res)=>{
       setLogininfo(res.data);
    })
  }
   logininfo.map=(logininfo)=>{
   const isadmin=(logininfo)=>
   {
      if (logininfo.role === "admin") 
      {
        
      } 
     else
     {

     }
   }};
   return(<>  
       
       <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <title>Admin</title>
  
 
  <body >
    <div className="container-scroller">
      <div className="row p-0 m-0 proBanner" id="proBanner">
        <div className="col-md-12 p-0 m-0">
          <div className="card-body card-body-padding d-flex align-items-center justify-content-between">
            <div className="ps-lg-1">
              <div className="d-flex align-items-center justify-content-between">
               
                <p style={{color:"antiquewhite" ,marginTop:"10px" }}>Welcome Admin</p>
              </div>
            </div>
            <div className="d-flex align-items-center justify-content-between">
              <i className="mdi mdi-home me-3 text-white"></i>
              <button id="bannerClose" class="btn border-0 p-0">
                <i className="mdi mdi-close text-white me-0"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
      </div>
     
      <nav className="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div className="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a className="navbar-brand brand-logo" href="/dashboard"><img src="assets/images/logo.svg" alt="logo" /></a>
          <a className="navbar-brand brand-logo-mini" href="/dashboard"><img src="assets/images/logo-mini.svg" alt="logo" /></a>
        </div>
        <div className="navbar-menu-wrapper d-flex align-items-stretch">
          <button className="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span className="mdi mdi-menu"></span>
          </button>
          <div className="search-field d-none d-md-block">
            <form className="d-flex align-items-center h-100" action="#">
              <div className="input-group">
                <div className="input-group-prepend bg-transparent">
                  <i className="input-group-text border-0 mdi mdi-magnify"></i>
                </div>
                <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects"/>
              </div>
            </form>
          </div>
          <ul className="navbar-nav navbar-nav-right">
            <li className="nav-item nav-profile dropdown">
              <a className="nav-link dropdown-toggle" id="profileDropdown"  data-bs-toggle="dropdown" aria-expanded="false">
                <div className="nav-profile-img">
                  <img src="assets/images/faces/face1.jpg" alt="image"/>
                  <span className="availability-status online"></span>
                </div>
               
              </a>
              
            </li>
           
            
            
            
            
          </ul>
          
        </div>
      </nav>
   
      <div className="container-fluid page-body-wrapper">
      
        <nav className="sidebar sidebar-offcanvas" id="sidebar">
          <ul className="nav">
            <li className="nav-item nav-profile">
              <a href="./Dashboard" className="nav-link">
                <div className="nav-profile-image">
                  <h6>Dashboard</h6>
                  
                  
                </div>
                <div className="nav-profile-text d-flex flex-column">
                 
                </div>
                <i className="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="index.html">
                <span className="menu-title">Manage Services</span>
                <img src="/assets/images/dashboard/home.png"></img>
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
                <span className="menu-title">Manage Service Centers</span>
                <i className="menu-arrow"></i>
                <i className="mdi mdi-crosshairs-gps menu-icon"></i>
              </a>
              <div class="collapse" id="ui-basic">
                <ul className="nav flex-column sub-menu">
                  <li className="nav-item"> <a class="nav-link" href="pages/ui-features/buttons.html">Buttons</a></li>
                  <li className="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Typography</a></li>
                </ul>
              </div>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="./Users">
                <span className="menu-title">Manage Users</span>
                <i className="mdi mdi-contacts menu-icon"></i>
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="./Payments">
                <span className="menu-title">Manage Payments</span>
                <i className="mdi mdi-format-list-bulleted menu-icon"></i>
              </a>
            </li>
           

            
           
           
          </ul>
        </nav> 
        <div className="main-panel">
          <div className="content-wrapper">

            <div className="page-header">
              <h3 className="page-title">
                <span className="page-title-icon bg-gradient-primary text-white me-2">
                  <image url="https://icons8.com/icon/86527/home" className="mdi mdi-home" ></image>
                   </span> <h1>Users</h1>
               </h3>
               </div>
            <div class="row">
          
             
          <meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
<title>Bootstrap Simple Data Table</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto"/>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"/>
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

{/* <script>
+(document).ready(function(){
	+('[data-toggle="tooltip"]').tooltip()
});
</script>  */}

<body>
<div class="container-xl">
    <div class="table-responsive">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><h2>Customer <b>Details</b></h2></div>
                    <div class="col-sm-4">
                        <div class="search-box">
                            <i class="material-icons">&#xE8B6;</i>
                            <input type="number" class="form-control" placeholder="Search&hellip;"/>
                        </div>
                    </div>
                </div>
            </div>
            <table class="table table-striped table-hover  table-responsive">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name <i class="fa fa-sort"></i></th>
                        <th>Last Name</th>
                        <th>Email <i class="fa fa-sort"></i></th>
                        <th>Created At</th>
                        <th>Role <i class="fa fa-sort"></i></th>
                        <th>Password</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                {isadmin ?("10"):(
                <tbody>
                         {logininfo.map((user)=>
                    <tr>
                        <td>{user.userId}</td>
                        <td>{user.fname}</td>
                        <td>{user.lname}</td>
                        <td>{user.email}</td>
                        <td>{user.createdAt}</td>
                        <td>{user.role}</td>
                        <td>{user.password}</td>
                        <td>
                            <a href="#" class="view" title="View" type="button" className="btn btn-outline-info btn-sm" ><i class="material-icons">&#xE417;</i></a>
                            <a href="#" class="edit" title="Edit" type="button" className="btn btn-outline-warning btn-sm"><i class="material-icons">&#xE254;</i></a>
                            <a href="#" class="delete" title="Delete" type="button" className="btn btn-outline-danger btn-sm" onClick={delpay}><i class="material-icons">&#xE872;</i></a>
                        </td>
                    </tr>)}
                            
                </tbody>)}
            </table>
            
        </div>
    </div>  
</div>   
</body>
            </div>
          </div>

        </div>
       
      </div>
     
   
              
  </body> 
      </>);
 }

export default Users;

import '../css/login.css'
import React, { useState } from 'react';
import axios from "axios"
import {useNavigate } from 'react-router-dom';



function Login() {

    const [credentials,setcredentials]=useState({email:"",password:""});
    const [logininfo, setLogininfo] = useState({});
    const history=useNavigate();

     const OnTextChange=(args)=>{
        var copyOfcredentials = {...credentials};
        copyOfcredentials[args.target.name]=args.target.value;
        setcredentials(copyOfcredentials);
     }

    
    
    const login=()=>{
         axios.post("http://localhost:1111/Users/login",credentials)
             .then((res)=>{
                setLogininfo(res.data);
             })
             

             if(logininfo.role ==="admin")
             {
               history("/Dashboard");
             }
             else
             {
               alert("INVALID CREDENTIALS");
             }
    }
   
 
    
  return (<>    <meta charset="UTF-8"/>
   <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet"/> 

   <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous"/><link rel="stylesheet" href="./style.css"/>

  <body>
    <div className="boxx-form">
		<div className="left">
			<div className="overlay">
			  <h1>Hello Admin</h1>
			  <p>No one is more cherished in this world than someone who lightens the burden of another. ...</p>

			</div>
		</div>
			<div className="right">
				<h1>Admin</h1>
					<div className="inputs">
                    <input type="text"
                                   placeholder="Enter UserName"
                                   value={credentials.email} 
                                   name='email'
                                   onChange={OnTextChange}/>
					<br/>
                    <input type="password"
                                    placeholder="Enter Password"
                                   value={credentials.password} 
                                   name='password'
                                    onChange={OnTextChange}/> 
			</div>
					<br/>
	
					<br/>
					<button type="submit" onClick={login}><h3>Login</h3></button>
		</div>
		
</div>
</body>        
</>);
}

export default Login;

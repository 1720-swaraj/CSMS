import {BrowserRouter as Router, Route, Routes} from "react-router-dom";
import Login from "./routes/Login";
import Dashboard from "./routes/Dashboard"
import Payments from "./routes/Payments";
import Users from "./routes/Users";

function App() {
    

  return (<>
      <Router>
	  <Routes>
		   <Route exact path="/" Component={Login}/>
		   <Route exact path="/Dashboard" Component={Dashboard}/>
		   <Route exact path="/Payments" Component={Payments}/>
		   <Route exact path="/Users" Component={Users}/>
	  </Routes>
	  </Router>
</>);
}

export default App;
package com.app.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.app.Services.ServicesServices;
import com.app.pojo.Services;

@CrossOrigin(origins="*")
@Controller
@RestController
@RequestMapping("/services")
public class ServicesController {

	
	 @Autowired
	 private ServicesServices serv;
	 
	 @GetMapping("/getserv")
	 public List<Services> getserv()
	 {
		 List<Services> services=serv.getServices();
		return services;
	 }
	 
}

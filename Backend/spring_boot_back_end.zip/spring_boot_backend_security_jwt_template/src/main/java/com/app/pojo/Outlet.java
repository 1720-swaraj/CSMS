package com.app.pojo;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name="Outlet")
public class Outlet {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long outletId;
     
	@Column(name="name",length=20)
	private String name;
	
	@Column(name="address",length=20)
	private String address;
	
	@Column(name="contact_no",length=20)
	private String contactNo;
	
	@Column(name="licence_no",length=20)
	private String licenceNo;
	
	//@OneToMany(mappedBy="outlet")
	//List<User>user=new ArrayList<>();

	
}

package com.app.Services;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.app.Dao.UsersDao;
import com.app.Dto.LoginDto;
import com.app.pojo.Users;


@Service
@Transactional
public class UserServices implements userServices{

	
	@Autowired
	private UsersDao userDao;

	@Override
	public List<Users> getUsers() {
		List<Users> user=userDao.findAll();
		return user;
	}

	@Override
	public String addUser(Users u) {
		
		userDao.save(u);
		return "user saved";
	}

	@Override
	public String deleteUser(Long id) {
		userDao.deleteById(id);
		return "user deleted sucesfully";
	}

	@Override
	public Users loginUser(LoginDto creds) {
		return userDao.findByEmailAndPassword(creds.getEmail(), creds.getPassword());
	}


	
	
	
}

package com.app.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.app.Dto.LoginDto;
import com.app.Services.UserServices;
import com.app.pojo.Users;


@CrossOrigin(origins="*")
@Controller
@RestController
@RequestMapping("/Users")
public class UsersController {
	
	@Autowired
	private UserServices us;
     
	@GetMapping("/get")
	public List<Users> getUser()
	{
		List<Users> user=us.getUsers();
		return user;
	}
	
	@PostMapping("/add")
	public String postUserById(@RequestBody Users user)
	{  
		return us.addUser(user);
	}
	
	@PutMapping("/update") 
	public String updateUserById(@RequestBody Users user,Long id) {
		
	   return us.addUser(user);
	}
    
	
	@DeleteMapping("/{id}")
	public String deleteUSer(@PathVariable Long id)
	{
	  return us.deleteUser(id);
	}
	
	@PostMapping("/login")
	public Users login(@RequestBody LoginDto creds) {
		return us.loginUser(creds);
	}
}



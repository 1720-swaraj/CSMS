package com.app.Services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.Dao.ServicesDao;
import com.app.pojo.Services;

@Service 
@Transactional
public class ServicesServices implements servicesServices{
	
	@Autowired
	private ServicesDao serv;

	@Override
	public List<Services> getServices() {
		List<Services> service=serv.findAll();
		return service;
	}
	
	

}

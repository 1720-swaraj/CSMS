package com.app.Services;

import com.app.pojo.Payments;

public interface paymentServices {
    
	public Payments getpayment( Long id);
}

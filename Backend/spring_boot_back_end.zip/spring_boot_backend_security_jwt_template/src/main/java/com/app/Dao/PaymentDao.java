package com.app.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojo.Payments;

public interface PaymentDao extends JpaRepository<Payments,Long>{

}

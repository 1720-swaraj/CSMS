package com.app.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name="appointment_details")
public class Appointment_Details{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="appointment_details_id")
	private Long appointmentDetailsId;
	
	@ManyToOne
	@JoinColumn(name = "appointment_id")
	Appointment appointment;
	
	@ManyToOne
	@JoinColumn(name = "service_id")
	Services service;
	
	@ManyToOne
	@JoinColumn(name = "manfac_id")
	Manufacturer manufacturer;
	
	@ManyToOne
	@JoinColumn(name = "model_id")
	Model model;
	
}

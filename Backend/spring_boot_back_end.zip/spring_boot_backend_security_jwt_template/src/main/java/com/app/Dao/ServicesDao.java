package com.app.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojo.Services;

public interface ServicesDao extends JpaRepository<Services,Long>{

}

package com.app.Services;



import java.util.List;

import com.app.Dto.LoginDto;
import com.app.pojo.Users;



public interface userServices {
	
	public List<Users> getUsers();
	public String addUser(Users u);
	public String deleteUser(Long id);
	public Users loginUser(LoginDto creds);
	
}

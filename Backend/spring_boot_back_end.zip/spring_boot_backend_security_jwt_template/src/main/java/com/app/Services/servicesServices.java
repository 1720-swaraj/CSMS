package com.app.Services;

import java.util.List;
import com.app.pojo.Services;


public interface servicesServices {
	
	public List<Services> getServices();

}

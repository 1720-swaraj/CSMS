package com.app.Services;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.app.Dao.PaymentDao;
import com.app.pojo.Payments;

@Service
@Transactional
public class PaymentServices implements paymentServices {

	@Autowired
	private PaymentDao paymentDao;

	@Override
	public Payments getpayment(Long id) {
		Payments pay=paymentDao.findById(id).orElseThrow();
		return pay;
	}
	
}

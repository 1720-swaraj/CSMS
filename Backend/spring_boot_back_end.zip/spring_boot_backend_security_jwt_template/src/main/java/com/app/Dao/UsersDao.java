package com.app.Dao;


import org.springframework.data.jpa.repository.JpaRepository;


import com.app.pojo.Users;


public interface UsersDao extends JpaRepository<Users,Long> {
	Users findByEmailAndPassword(String email,String password);
}

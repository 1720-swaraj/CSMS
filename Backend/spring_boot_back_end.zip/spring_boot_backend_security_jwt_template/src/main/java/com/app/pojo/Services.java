package com.app.pojo;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name="Services")
public class Services {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long serviceId;
	
	@Column(name="name", length=20)
	private String name;
	
	@Column(name="description",length=20)
	private String description;
    
	@Column(name="price")
	private int price;
	
	@Column(name="duration",length=20)
	private String duration;
	

}

package com.app.dao;
import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojo.*;

public interface ServicesDao extends JpaRepository<Services,Long>{

}

package com.app.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="appointment_details")
public class Appointment_Details{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="appointment_details_id")
	private Long appointmentDetailsId;
	
	@ManyToOne
	@JoinColumn(name = "appointment_id")
	Appointment appointment;
	
	@ManyToOne
	@JoinColumn(name = "service_id")
	Services service;
	
	@ManyToOne
	@JoinColumn(name = "manfac_id")
	Manufacturer manufacturer;
	
	@ManyToOne
	@JoinColumn(name = "model_id")
	Model model;
	
	public Appointment_Details() {
		
	}

	public Appointment getAppointment() {
		return appointment;
	}

	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}

	public Services getService() {
		return service;
	}

	public void setService(Services service) {
		this.service = service;
	}

	public Manufacturer getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(Manufacturer manufacturer) {
		this.manufacturer = manufacturer;
	}

	public Model getModel() {
		return model;
	}

	public void setModel(Model model) {
		this.model = model;
	}
	
	
	
}
